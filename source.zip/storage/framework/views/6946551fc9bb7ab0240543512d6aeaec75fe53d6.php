

<?php $__env->startSection('Content'); ?>

<div class="content-body">
    <div class="container-fluid">
        <div class="row page-titles mx-0">
            <div class="col-sm-6 p-md-0">
                <div class="welcome-text">
                    <h4>Add Courses</h4>
                </div>
            </div>
        </div>
        <!-- row -->
        <div class="row">
            <div class="col-xl-12 col-xxl-6 col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <div class="basic-form">
                            <?php if(session('message')): ?>
                                <div class="alert alert-success">
                                    <ul>
                                        <li><?php echo session('message'); ?></li>
                                    </ul>
                                </div>
                            <?php endif; ?>


                            <form action="/admin/courses/store_courses" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="form-group col-md-6">
                                        <label for="">Course Name</label>
                                        <input type="hidden" class="form-control input-default " name="id" value="">
                                        <input type="text" class="form-control input-default " name="course_name" value="">
                                    </div>
                                    <div class="form-group col-md-6">
                                        <label for="">Teacher Name</label>
                                        <br>
                                        
                                        <select name="teacher_name" id="">
                                            <option selected disabled>Select Teacher Name</option>
                                            <?php $__currentLoopData = $Teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($Teacher->id); ?>"><?php echo e($Teacher->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="form-group col-md-6">
                                        <label for="">Type</label>
                                        <input type="text" class="form-control input-default " name="type" value="">
                                    </div>
                                    <div class="form-group col-md-6">
                                        <label for="">Fees</label>
                                        <input type="text" class="form-control input-default " name="fees" value="">
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="form-group col-md-6">
                                        <label for="">Featured Image</label>
                                        <input type="file" class="form-control input-default " id="CheangeImg" name="featured_image" value="">
                                    </div>

                                    <div class="form-group col-md-6">
                                        <label for="">Preview</label>
                                        <br>
                                        <img id="img_preview" src="#" alt="your image" style="
                                        width: 250px;
                                    ">
                                    </div>
                                </div>

                                <button type="submit" class="btn btn-primary">Submit</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\LocalServer\htdocs\techitalents\Skillgroom\source\resources\views/Admin/courses/add_course.blade.php ENDPATH**/ ?>