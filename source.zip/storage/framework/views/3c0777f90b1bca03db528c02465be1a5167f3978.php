

<?php $__env->startSection('Content'); ?>

<div class="content-body">
    <div class="container-fluid">

        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Booking Inquiries</h4>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-responsive-sm" id="Classes">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Class Name</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Contact Number</th>
                                        <th>Country</th>
                                        <th>State</th>
                                        <th>City</th>

                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(isset($Classes)): ?>
                                    <?php $__currentLoopData = $Classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                    <th><?php echo e($Class->id); ?></th>
                                    <th><?php echo e($Class->class_name); ?></th>
                                        <td><?php echo e($Class->first_name); ?> <?php echo e($Class->last_name); ?></td>
                                        <td><?php echo e($Class->email); ?></td>
                                        <td><span class="badge badge-primary"><?php echo e($Class->contact); ?></span>
                                        </td>
                                        <td><?php echo e($Class->country); ?></td>
                                        <td><?php echo e($Class->state); ?></td>
                                        <td><?php echo e($Class->city); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                    <tr>
                                        <td>No Data Found</td>
                                    </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>

                            <?php echo e($Classes->links()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\LocalServer\htdocs\techitalents\Skillgroom\source\resources\views/Admin/layouts/classes.blade.php ENDPATH**/ ?>