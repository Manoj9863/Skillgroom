

<?php $__env->startSection('Content'); ?>

<div class="content-body">
    <div class="container-fluid">

        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Partners List</h4>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-responsive-sm" id="Partners">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Mobile Number</th>
                                        <th>State</th>
                                        <th>City</th>
                                        <th>Tution</th>
                                        <th>Subjects</th>
                                        <th>Standard</th>
                                        <th>Education</th>
                                        <th>No of Students</th>
                                        <th>website</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(isset($Partners)): ?>
                                    <?php $__currentLoopData = $Partners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Partner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                    <th><?php echo e($Partner->id); ?></th>
                                        <td><?php echo e($Partner->name); ?></td>
                                        <td><?php echo e($Partner->email); ?></td>
                                        <td><span class="badge badge-primary"><?php echo e($Partner->mobile); ?></span>
                                        </td>
                                        <td><?php echo e($Partner->state); ?></td>
                                        <td><?php echo e($Partner->city); ?></td>
                                        <td><?php echo e($Partner->tution); ?></td>
                                        <td><?php echo e($Partner->subjects); ?></td>
                                        <td><?php echo e($Partner->standard); ?></td>
                                        <td><?php echo e($Partner->education); ?></td>
                                        <td><?php echo e($Partner->no_of_students); ?></td>
                                        <td><?php echo e($Partner->website); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                    <tr>
                                        <td>No Data Found</td>
                                    </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>

                            <?php echo e($Partners->links()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\LocalServer\htdocs\techitalents\Skillgroom\source\resources\views/Admin/layouts/partners.blade.php ENDPATH**/ ?>