

<?php $__env->startSection('Content'); ?>

<div class="content-body">
    <div class="container-fluid">

        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Inquiry Lists</h4>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-responsive-sm" id="Inquiries">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Mobile Number</th>
                                        <th>Location</th>
                                        <th>Category</th>
                                        <th>Inquiry</th>

                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(isset($Inquiry)): ?>
                                    <?php $__currentLoopData = $Inquiry; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Inquiries): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                    <th><?php echo e($Inquiries->id); ?></th>
                                        <td><?php echo e($Inquiries->name); ?></td>
                                        <td><?php echo e($Inquiries->email); ?></td>
                                        <td><span class="badge badge-primary"><?php echo e($Inquiries->mobile); ?></span>
                                        </td>
                                        <td><?php echo e($Inquiries->location); ?></td>
                                        <td><?php echo e($Inquiries->category); ?></td>
                                        <td><?php echo e($Inquiries->inquiry); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                    <tr>
                                        <td>No Data Found</td>
                                    </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>

                            <?php echo e($Inquiry->links()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\LocalServer\htdocs\techitalents\Skillgroom\source\resources\views/admin/layouts/inquiry.blade.php ENDPATH**/ ?>