<div class="deznav">
    <div class="deznav-scroll">
        <ul class="metismenu" id="menu">
            <li class="nav-label first">Main Menu</li>
            <li class="mega-menu mega-menu-lg"><a class="has-arrow ai-icon" href="/admin/dashboard" aria-expanded="false">
                    <svg id="icon-home" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-home"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg>
                    <span class="nav-text">Dashboard</span>
                </a>
            </li>
            
            
            
            <?php if(Auth::guard('super_admin')->check() || Auth::guard('teacher')->check()): ?>
            
            <li class="nav-label">Data</li>
            <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
                    <svg id="icon-table" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-server"><rect x="2" y="2" width="20" height="8" rx="2" ry="2"></rect><rect x="2" y="14" width="20" height="8" rx="2" ry="2"></rect><line x1="6" y1="6" x2="6" y2="6"></line><line x1="6" y1="18" x2="6" y2="18"></line></svg>
                    <span class="nav-text">Classes List</span>
                </a>
                <ul aria-expanded="false">
                    <li><a href="/admin/classes">Classes</a></li>
                </ul>
            </li>
            <?php endif; ?>
            
            <?php if(Auth::guard('super_admin')->check()): ?>
            
            <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
                <svg id="icon-table" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-server"><rect x="2" y="2" width="20" height="8" rx="2" ry="2"></rect><rect x="2" y="14" width="20" height="8" rx="2" ry="2"></rect><line x1="6" y1="6" x2="6" y2="6"></line><line x1="6" y1="18" x2="6" y2="18"></line></svg>
                <span class="nav-text">Partner List</span>
            </a>
            <ul aria-expanded="false">
                <li><a href="/admin/partners">Partners</a></li>
            </ul>
        </li>

        <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
            <svg id="icon-table" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-server"><rect x="2" y="2" width="20" height="8" rx="2" ry="2"></rect><rect x="2" y="14" width="20" height="8" rx="2" ry="2"></rect><line x1="6" y1="6" x2="6" y2="6"></line><line x1="6" y1="18" x2="6" y2="18"></line></svg>
            <span class="nav-text">Inquiry List</span>
        </a>
        <ul aria-expanded="false">
            <li><a href="/admin/inquiry">Inquiry</a></li>
        </ul>
    </li>

    <li class="nav-label">Teachers</li>
    <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
            <svg id="icon-table" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-server"><rect x="2" y="2" width="20" height="8" rx="2" ry="2"></rect><rect x="2" y="14" width="20" height="8" rx="2" ry="2"></rect><line x1="6" y1="6" x2="6" y2="6"></line><line x1="6" y1="18" x2="6" y2="18"></line></svg>
            <span class="nav-text">Teachers List</span>
        </a>
        <ul aria-expanded="false">
            <li><a href="/admin/teachers/teachers_lists">Teachers</a></li>
        </ul>
    </li>


    <li class="nav-label">Courses</li>
            <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
                    <svg id="icon-table" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-server"><rect x="2" y="2" width="20" height="8" rx="2" ry="2"></rect><rect x="2" y="14" width="20" height="8" rx="2" ry="2"></rect><line x1="6" y1="6" x2="6" y2="6"></line><line x1="6" y1="18" x2="6" y2="18"></line></svg>
                    <span class="nav-text">Courses List</span>
                </a>
                <ul aria-expanded="false">
                    <li><a href="/admin/courses/list">Courses</a></li>
                </ul>
            </li>

            <?php endif; ?>
            
        </ul>
    </div>


</div><?php /**PATH E:\LocalServer\htdocs\techitalents\Skillgroom\source\resources\views/Admin/common/sidebar.blade.php ENDPATH**/ ?>